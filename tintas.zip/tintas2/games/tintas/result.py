from enum import Enum


class TintasResult(Enum):
    WIN = 0,
    LOOSE = 1,
    DRAW = 2
